﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BanleWebsite.Models
{
    public class ResultViewModels
    {
        public object data { get; set; }
        public string message { get; set; }
    }
}